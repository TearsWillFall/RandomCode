package TestPluginNoMethods;

sub new { return bless({}), $_[0]; }

1;