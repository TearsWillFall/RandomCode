package TestPluginNewFails;

sub new { die; }

1;